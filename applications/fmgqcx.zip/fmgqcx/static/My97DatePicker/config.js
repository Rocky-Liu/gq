var langList = 
[
	{name:'en',	charset:'UTF-8'},
	{name:'zh-cn',	charset:'UTF-8'},
	{name:'zh-tw',	charset:'UTF-8'}
];

var skinList = 
[
	{name:'default',	charset:'UTF-8'},
	{name:'whyGreen',	charset:'UTF-8'}
];